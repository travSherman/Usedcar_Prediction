# AI4ALL_Used_Car_Pricing
Machine Learning model to predict the price of a used car
